"""Team prompts package."""
